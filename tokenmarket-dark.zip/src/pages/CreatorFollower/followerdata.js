export const followers = [
  {
    name: "Floyd Miles",
    img: "assets/images/author/10.jpg",
  },
  {
    name: "Leslie Alexander",
    img: "assets/images/author/9.jpg",
  },
  {
    name: "Ronald Richards",
    img: "assets/images/author/11.jpg",
  },
  {
    name: "Dianne Russell",
    img: "assets/images/author/12.jpg",
  },
  {
    name: "Darrell Steward",
    img: "assets/images/author/13.jpg",
  },
  {
    name: "Marvin McKinney",
    img: "assets/images/author/14.jpg",
  },
  {
    name: "Jerome Bell",
    img: "assets/images/author/15.jpg",
  },
  {
    name: "Courtney Henry",
    img: "assets/images/author/16.jpg",
  },
  {
    name: "Theresa Webb",
    img: "assets/images/author/17.jpg",
  },
  {
    name: "Kathryn Murphy",
    img: "assets/images/author/18.jpg",
  },
  {
    name: "Arlene McCoy",
    img: "assets/images/author/19.jpg",
  },
  {
    name: "Eleanor Pena",
    img: "assets/images/author/20.jpg",
  },
  {
    name: "Wade Warren",
    img: "assets/images/author/2.jpg",
  },
  {
    name: "Jenny Wilson",
    img: "assets/images/author/5.jpg",
  },
  {
    name: "Jenny Wilson",
    img: "assets/images/author/5.jpg",
  },
];
