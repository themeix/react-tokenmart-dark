export const blogs = [
  {
    title: "    Save Thousands Of Lives Through This NFT",
    img: "assets/images/blog/2.jpg",
  },
  {
    title: "     Honoring Black History Month with Toddlers",
    img: "assets/images/blog/3.jpg",
  },
  {
    title: "NFT Market – A Compact the Big Benefits",
    img: "assets/images/blog/4.jpg",
  },
  {
    title: "  Mindfulness Activities for Kids &amp; Toddlers with NFT",
    img: "assets/images/blog/1.jpg",
  },

  {
    title: "       Honoring Black History Month with Toddlers",
    img: "assets/images/blog/8.jpg",
  },
  {
    title: "    Setting Intentions Instead of Resolutions for 2021",
    img: "assets/images/blog/9.jpg",
  },
  {
    title: "    Clever Ways to Purchase Extraordinart Items from NFT Market",
    img: "assets/images/blog/10.jpg",
  },
  {
    title: "  How to Save Money on Baby Essentials for NFT",
    img: "assets/images/blog/11.jpg",
  },
  {
    title: "  Mindfulness Activities for Kids &amp; Toddlers with NFT",
    img: "assets/images/blog/1.jpg",
  },

  {
    title: "       Honoring Black History Month with Toddlers",
    img: "assets/images/blog/8.jpg",
  },
  {
    title: "    Setting Intentions Instead of Resolutions for 2021",
    img: "assets/images/blog/9.jpg",
  },
  {
    title: "    Clever Ways to Purchase Extraordinart Items from NFT Market",
    img: "assets/images/blog/10.jpg",
  },
  {
    title: "  How to Save Money on Baby Essentials for NFT",
    img: "assets/images/blog/11.jpg",
  },

  {
    title: "    Setting Intentions Instead of Resolutions for 2021",
    img: "assets/images/blog/9.jpg",
  },
  {
    title: "    Clever Ways to Purchase Extraordinart Items from NFT Market",
    img: "assets/images/blog/10.jpg",
  },
  {
    title: "  How to Save Money on Baby Essentials for NFT",
    img: "assets/images/blog/11.jpg",
  },
  {
    title: "Liki Trike – A Compact Trike with the Big Benefits",
    img: "assets/images/blog/12.jpg",
  },

  {
    title: "NFT Market – A Compact the Big Benefits",
    img: "assets/images/blog/13.jpg",
  },
];